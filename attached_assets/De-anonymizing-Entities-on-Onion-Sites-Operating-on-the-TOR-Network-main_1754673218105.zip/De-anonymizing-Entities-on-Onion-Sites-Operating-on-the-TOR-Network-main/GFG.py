a=100
b=20
temp=a
a=b
b=temp
print(a,b)
